import networkx as nx
G=nx.Graph()
G.add_edge(1,0)
G.add_edge(3,0)
G.add_edge(4,0)
G.add_edge(2,1)
G.add_edge(5,1)
G.add_edge(6,5)
G.add_edge(9,5)
G.add_edge(7,6)
G.add_edge(8,7)
nx.draw(G,with_labels = True)
import matplotlib.pyplot as plt
plt.savefig('NodesGraph.png')
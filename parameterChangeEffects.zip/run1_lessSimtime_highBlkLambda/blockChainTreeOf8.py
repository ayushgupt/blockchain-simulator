Node#8
--------------------------------------------------
--------------------------------------------------
Block#0
--------------------------------------------------
Block ID:             0
Created by node:      -1
Length in BlockChain: 1
Previous Block:       -1
Created at:           0
Received at:           0
	TxnID 0: -1 pays 0 93.8975 coins
	TxnID 1: -1 pays 1 59.7442 coins
	TxnID 2: -1 pays 2 66.5143 coins
	TxnID 3: -1 pays 3 14.5971 coins
	TxnID 4: -1 pays 4 77.5547 coins
	TxnID 5: -1 pays 5 53.1448 coins
	TxnID 6: -1 pays 6 2.2877 coins
	TxnID 7: -1 pays 7 41.4253 coins
	TxnID 8: -1 pays 8 12.61 coins
	TxnID 9: -1 pays 9 56.3016 coins
Block#1
--------------------------------------------------
Block ID:             1
Created by node:      4
Length in BlockChain: 2
Previous Block:       0
Created at:           6.88599
Received at:           7.41334
	TxnID 12: 6 pays 0 1.85084 coins
	TxnID 13: 1 pays 9 0.192685 coins
	TxnID 14: 1 pays 7 40.2587 coins
	TxnID 15: 1 pays 6 11.1841 coins
	TxnID 16: 2 pays 3 22.0351 coins
	TxnID 17: 0 pays 7 23.3676 coins
	TxnID 18: 0 pays 7 66.342 coins
	TxnID 19: 2 pays 3 44.0022 coins
	TxnID 20: 7 pays 0 17.2225 coins
	TxnID 21: 3 pays 8 5.90424 coins
	TxnID 26: 6 pays 4 0.00685504 coins
	TxnID 27: 7 pays 2 39.3556 coins
	TxnID 29: 2 pays 9 13.2364 coins
	TxnID 31: 3 pays 9 10.3162 coins
	TxnID 32: 5 pays 8 52.5332 coins
	TxnID 33: 2 pays 7 17.3185 coins
	TxnID 36: 8 pays 2 11.5853 coins
	TxnID 38: 8 pays 7 11.4856 coins
	TxnID 39: 4 pays 3 15.3188 coins
	TxnID 40: 1 pays 3 8.09515 coins
	TxnID 41: 7 pays 4 4.21362 coins
	TxnID 43: 9 pays 6 22.442 coins
	TxnID 45: 9 pays 7 24.0848 coins
	TxnID 49: 3 pays 4 2.16882 coins
	TxnID 51: 8 pays 9 11.5062 coins
	TxnID 54: 9 pays 7 47.0457 coins
	TxnID 55: 8 pays 1 8.73828 coins
	TxnID 56: 3 pays 6 0.644659 coins
	TxnID 58: 6 pays 5 0.643221 coins
	TxnID 62: 6 pays 8 1.80018 coins
	TxnID 63: 7 pays 5 27.5059 coins
	TxnID 66: 0 pays 5 3.2964 coins
	TxnID 68: 8 pays 1 0.389312 coins
	TxnID 69: 1 pays 7 0.979592 coins
	TxnID 71: 9 pays 0 10.5857 coins
	TxnID 77: 6 pays 8 1.23311 coins
	TxnID 85: -1 pays 4 50 coins
Block#2
--------------------------------------------------
Block ID:             2
Created by node:      5
Length in BlockChain: 3
Previous Block:       1
Created at:           8.38542
Received at:           8.59322
	TxnID 78: 5 pays 7 1.36949 coins
	TxnID 79: 3 pays 9 10.8828 coins
	TxnID 81: 6 pays 3 1.11146 coins
	TxnID 82: 6 pays 1 0.888073 coins
	TxnID 86: 4 pays 7 5.53441 coins
	TxnID 87: 8 pays 1 2.72185 coins
	TxnID 88: 2 pays 0 1.43884 coins
	TxnID 90: 8 pays 9 12.2973 coins
	TxnID 91: 6 pays 5 0.398137 coins
	TxnID 93: 6 pays 2 13.7626 coins
	TxnID 95: 9 pays 8 0.11281 coins
	TxnID 96: 1 pays 6 6.33903 coins
	TxnID 97: 1 pays 8 0.361093 coins
	TxnID 99: 8 pays 7 38.3664 coins
	TxnID 102: -1 pays 5 50 coins
Block#3
--------------------------------------------------
Block ID:             3
Created by node:      1
Length in BlockChain: 4
Previous Block:       2
Created at:           10.288
Received at:           10.7747
	TxnID 37: 5 pays 0 26.981 coins
	TxnID 65: 1 pays 6 41.5902 coins
	TxnID 72: 9 pays 8 7.20025 coins
	TxnID 73: 4 pays 7 40.6936 coins
	TxnID 74: 4 pays 0 51.7631 coins
	TxnID 94: 3 pays 2 10.1201 coins
	TxnID 100: 4 pays 3 64.1311 coins
	TxnID 101: 1 pays 3 2.44412 coins
	TxnID 103: 8 pays 4 69.3532 coins
	TxnID 104: 0 pays 4 6.13983 coins
	TxnID 106: 3 pays 9 70.4662 coins
	TxnID 107: 3 pays 2 134.707 coins
	TxnID 108: 4 pays 6 13.5621 coins
	TxnID 110: 0 pays 8 1.14415 coins
	TxnID 111: 8 pays 5 7.33818 coins
	TxnID 116: 3 pays 2 1.23025 coins
	TxnID 117: 3 pays 4 101.448 coins
	TxnID 118: 2 pays 5 6.49961 coins
	TxnID 121: 9 pays 2 0.82012 coins
	TxnID 127: 1 pays 5 3.88742 coins
	TxnID 128: -1 pays 1 50 coins
Block#4
--------------------------------------------------
Block ID:             4
Created by node:      0
Length in BlockChain: 5
Previous Block:       3
Created at:           11.3915
Received at:           12.0138
	TxnID 23: 2 pays 7 12.7067 coins
	TxnID 24: 1 pays 6 13.8052 coins
	TxnID 25: 2 pays 5 55.4363 coins
	TxnID 28: 1 pays 3 52.7678 coins
	TxnID 30: 1 pays 9 38.1261 coins
	TxnID 34: 4 pays 3 51.7301 coins
	TxnID 35: 4 pays 0 54.0024 coins
	TxnID 42: 0 pays 9 80.6798 coins
	TxnID 44: 5 pays 7 34.8181 coins
	TxnID 46: 2 pays 3 36.0354 coins
	TxnID 52: 2 pays 0 34.9129 coins
	TxnID 53: 5 pays 6 11.3087 coins
	TxnID 60: 5 pays 7 11.0034 coins
	TxnID 61: 9 pays 7 55.2373 coins
	TxnID 76: 2 pays 9 35.6228 coins
	TxnID 105: 5 pays 1 30.5522 coins
	TxnID 109: 8 pays 3 61.7991 coins
	TxnID 112: 6 pays 5 23.4401 coins
	TxnID 115: 6 pays 4 14.1043 coins
	TxnID 120: 6 pays 2 12.4376 coins
	TxnID 122: 0 pays 5 13.5963 coins
	TxnID 124: 7 pays 2 20.719 coins
	TxnID 126: 3 pays 7 168.368 coins
	TxnID 129: 5 pays 2 17.6427 coins
	TxnID 131: 8 pays 1 4.53726 coins
	TxnID 133: 4 pays 5 10.4251 coins
	TxnID 135: 7 pays 4 1.34023 coins
	TxnID 141: -1 pays 0 50 coins
Block#5
--------------------------------------------------
Block ID:             5
Created by node:      9
Length in BlockChain: 6
Previous Block:       4
Created at:           12.3844
Received at:           12.6146
	TxnID 10: 7 pays 8 37.4467 coins
	TxnID 11: 7 pays 3 28.6707 coins
	TxnID 134: 0 pays 5 21.0021 coins
	TxnID 136: 5 pays 3 25.1844 coins
	TxnID 137: 6 pays 4 3.24352 coins
	TxnID 139: 7 pays 4 0.0615452 coins
	TxnID 142: 6 pays 8 0.751908 coins
	TxnID 143: 3 pays 6 9.25395 coins
	TxnID 145: 0 pays 3 22.366 coins
	TxnID 148: 6 pays 7 3.59328 coins
	TxnID 149: 9 pays 1 8.79743 coins
	TxnID 150: -1 pays 9 50 coins
Block#6
--------------------------------------------------
Block ID:             6
Created by node:      8
Length in BlockChain: 7
Previous Block:       5
Created at:           15.1976
Received at:           15.1976
	TxnID 80: 1 pays 2 9.03568 coins
	TxnID 152: 4 pays 3 14.6759 coins
	TxnID 155: 5 pays 2 11.5687 coins
	TxnID 161: 7 pays 5 18.3314 coins
	TxnID 163: 7 pays 4 121.281 coins
	TxnID 165: 3 pays 8 301.378 coins
	TxnID 169: 4 pays 9 14.7577 coins
	TxnID 170: 4 pays 6 12.9235 coins
	TxnID 174: 6 pays 1 8.7135 coins
	TxnID 175: -1 pays 8 50 coins
Block#7
--------------------------------------------------
Block ID:             7
Created by node:      0
Length in BlockChain: 8
Previous Block:       6
Created at:           24.7612
Received at:           25.3819
	TxnID 75: 4 pays 7 67.9514 coins
	TxnID 157: 2 pays 0 21.4219 coins
	TxnID 158: 4 pays 9 14.803 coins
	TxnID 159: 4 pays 7 4.5213 coins
	TxnID 160: 4 pays 5 12.1387 coins
	TxnID 164: 7 pays 1 98.9318 coins
	TxnID 166: 7 pays 8 76.2603 coins
	TxnID 167: 5 pays 9 6.88349 coins
	TxnID 168: 1 pays 0 14.2256 coins
	TxnID 171: 8 pays 0 92.5737 coins
	TxnID 172: 2 pays 3 0.390201 coins
	TxnID 177: 2 pays 3 1.15193 coins
	TxnID 178: 5 pays 6 0.375852 coins
	TxnID 181: 6 pays 1 0.330966 coins
	TxnID 186: 0 pays 8 75.1358 coins
	TxnID 187: 1 pays 8 0.80472 coins
	TxnID 191: 7 pays 5 4.02352 coins
	TxnID 192: 3 pays 7 278.495 coins
	TxnID 193: 3 pays 8 45.4545 coins
	TxnID 196: 7 pays 8 3.85988 coins
	TxnID 197: 8 pays 4 35.2827 coins
	TxnID 200: 3 pays 0 45.9303 coins
	TxnID 202: 7 pays 3 2.19163 coins
	TxnID 205: 8 pays 6 4.92248 coins
	TxnID 206: 5 pays 0 0.312256 coins
	TxnID 207: 7 pays 0 2.6011 coins
	TxnID 208: 8 pays 9 39.4502 coins
	TxnID 211: 5 pays 3 0.0446373 coins
	TxnID 213: 7 pays 6 1.99437 coins
	TxnID 215: 6 pays 1 4.97818 coins
	TxnID 216: 6 pays 9 1.61989 coins
	TxnID 217: 6 pays 5 0.146183 coins
	TxnID 218: 0 pays 4 32.5157 coins
	TxnID 219: 5 pays 4 0.216143 coins
	TxnID 220: 4 pays 3 68.3205 coins
	TxnID 222: 7 pays 1 2.24341 coins
	TxnID 225: 0 pays 6 1.55304 coins
	TxnID 226: 5 pays 8 0.360977 coins
	TxnID 228: 5 pays 0 0.138357 coins
	TxnID 231: 8 pays 9 28.2343 coins
	TxnID 232: 8 pays 6 13.2717 coins
	TxnID 233: 9 pays 4 30.8576 coins
	TxnID 236: 8 pays 5 10.733 coins
	TxnID 237: 0 pays 4 11.0375 coins
	TxnID 238: 5 pays 7 0.401657 coins
	TxnID 239: 8 pays 5 10.8544 coins
	TxnID 240: 4 pays 5 49.3788 coins
	TxnID 241: 6 pays 1 2.64213 coins
	TxnID 256: -1 pays 0 50 coins
Block#8
--------------------------------------------------
Block ID:             8
Created by node:      2
Length in BlockChain: 9
Previous Block:       7
Created at:           29.1978
Received at:           30.3677
	TxnID 84: 5 pays 0 34.0318 coins
	TxnID 98: 4 pays 7 65.6975 coins
	TxnID 114: 5 pays 1 46.7422 coins
	TxnID 123: 6 pays 0 10.9294 coins
	TxnID 125: 6 pays 2 16.3604 coins
	TxnID 130: 6 pays 1 9.93026 coins
	TxnID 140: 1 pays 8 41.9909 coins
	TxnID 146: 2 pays 1 4.98378 coins
	TxnID 151: 0 pays 5 41.5341 coins
	TxnID 153: 6 pays 9 6.77705 coins
	TxnID 154: 6 pays 9 6.21022 coins
	TxnID 156: 9 pays 3 62.419 coins
	TxnID 162: 6 pays 9 9.10415 coins
	TxnID 173: 1 pays 4 8.32445 coins
	TxnID 176: 7 pays 8 95.9483 coins
	TxnID 179: 2 pays 5 2.8845 coins
	TxnID 180: 6 pays 2 1.89342 coins
	TxnID 182: 6 pays 9 4.84215 coins
	TxnID 183: 1 pays 0 4.65967 coins
	TxnID 198: 1 pays 9 8.30793 coins
	TxnID 204: 1 pays 0 2.49408 coins
	TxnID 209: 2 pays 0 5.82883 coins
	TxnID 214: 8 pays 3 29.3472 coins
	TxnID 221: 1 pays 0 6.35798 coins
	TxnID 243: 8 pays 6 36.9172 coins
	TxnID 245: 8 pays 6 3.72295 coins
	TxnID 248: 3 pays 4 65.4118 coins
	TxnID 251: 0 pays 1 67.5542 coins
	TxnID 252: 5 pays 3 0.0383046 coins
	TxnID 254: 0 pays 2 72.5963 coins
	TxnID 255: 7 pays 0 1.86342 coins
	TxnID 257: 7 pays 9 4.89503 coins
	TxnID 258: 6 pays 1 6.93838 coins
	TxnID 259: 1 pays 9 4.62433 coins
	TxnID 260: 1 pays 5 8.1656 coins
	TxnID 261: 8 pays 1 0.0291333 coins
	TxnID 263: 4 pays 2 4.07823 coins
	TxnID 264: 6 pays 9 2.85522 coins
	TxnID 265: 2 pays 0 0.591577 coins
	TxnID 267: 8 pays 9 0.946941 coins
	TxnID 269: 7 pays 1 71.1809 coins
	TxnID 270: 7 pays 1 67.6981 coins
	TxnID 271: 5 pays 0 108.669 coins
	TxnID 272: 0 pays 1 55.3027 coins
	TxnID 273: 0 pays 8 24.3679 coins
	TxnID 274: 4 pays 3 4.18021 coins
	TxnID 275: 9 pays 1 70.9672 coins
	TxnID 276: 2 pays 9 0.875112 coins
	TxnID 278: 2 pays 0 0.361607 coins
	TxnID 280: 4 pays 6 0.940373 coins
	TxnID 283: 0 pays 5 16.9117 coins
	TxnID 284: 2 pays 6 0.0748596 coins
	TxnID 286: 0 pays 6 48.4791 coins
	TxnID 290: 3 pays 2 11.6921 coins
	TxnID 294: -1 pays 2 50 coins
Block#9
--------------------------------------------------
Block ID:             9
Created by node:      4
Length in BlockChain: 10
Previous Block:       8
Created at:           31.7262
Received at:           32.2552
	TxnID 47: 1 pays 3 39.0694 coins
	TxnID 57: 2 pays 1 45.3979 coins
	TxnID 59: 1 pays 7 21.0308 coins
	TxnID 64: 1 pays 0 42.9964 coins
	TxnID 83: 2 pays 5 10.1735 coins
	TxnID 89: 1 pays 3 31.1207 coins
	TxnID 92: 2 pays 8 51.6725 coins
	TxnID 119: 5 pays 0 27.4861 coins
	TxnID 144: 1 pays 8 38.3213 coins
	TxnID 184: 6 pays 3 5.93872 coins
	TxnID 185: 4 pays 5 20.1557 coins
	TxnID 188: 6 pays 5 2.63283 coins
	TxnID 190: 0 pays 4 107.865 coins
	TxnID 194: 4 pays 5 1.33365 coins
	TxnID 195: 4 pays 9 5.15265 coins
	TxnID 201: 2 pays 4 6.88409 coins
	TxnID 223: 1 pays 6 10.6731 coins
	TxnID 242: 1 pays 6 10.2929 coins
	TxnID 244: 4 pays 6 24.4238 coins
	TxnID 246: 1 pays 0 12.6227 coins
	TxnID 262: 6 pays 1 52.3435 coins
	TxnID 279: 0 pays 2 46.4016 coins
	TxnID 282: 5 pays 7 125.584 coins
	TxnID 292: 0 pays 1 3.64131 coins
	TxnID 296: 6 pays 2 10.1826 coins
	TxnID 297: 2 pays 5 58.1907 coins
	TxnID 298: 1 pays 7 0.875063 coins
	TxnID 299: 3 pays 1 12.981 coins
	TxnID 301: 8 pays 9 0.175958 coins
	TxnID 302: 8 pays 0 0.886621 coins
	TxnID 303: 7 pays 4 53.2499 coins
	TxnID 304: 4 pays 5 2.45713 coins
	TxnID 306: 4 pays 8 2.30697 coins
	TxnID 308: 5 pays 4 23.8775 coins
	TxnID 310: 8 pays 7 60.8207 coins
	TxnID 311: 0 pays 3 9.60117 coins
	TxnID 313: 6 pays 5 15.0472 coins
	TxnID 314: 3 pays 0 3.92228 coins
	TxnID 315: 7 pays 9 55.1187 coins
	TxnID 316: 1 pays 0 25.2102 coins
	TxnID 317: 5 pays 6 5.65679 coins
	TxnID 318: 0 pays 8 18.4673 coins
	TxnID 320: 0 pays 4 18.8209 coins
	TxnID 321: 4 pays 8 36.908 coins
	TxnID 322: 8 pays 4 72.3277 coins
	TxnID 323: 8 pays 9 0.971504 coins
	TxnID 326: 4 pays 9 18.2392 coins
	TxnID 327: -1 pays 4 50 coins
Block#10
--------------------------------------------------
Block ID:             10
Created by node:      8
Length in BlockChain: 11
Previous Block:       9
Created at:           36.7962
Received at:           36.7962
	TxnID 113: 4 pays 1 61.8908 coins
	TxnID 268: 6 pays 3 69.5927 coins
	TxnID 281: 9 pays 0 81.1528 coins
	TxnID 285: 6 pays 9 34.1177 coins
	TxnID 288: 9 pays 8 88.0048 coins
	TxnID 291: 9 pays 1 17.3025 coins
	TxnID 305: 0 pays 9 90.3728 coins
	TxnID 312: 2 pays 3 21.6373 coins
	TxnID 319: 3 pays 6 63.0553 coins
	TxnID 324: 5 pays 2 8.68016 coins
	TxnID 325: 7 pays 4 55.592 coins
	TxnID 328: 8 pays 6 48.1934 coins
	TxnID 329: 1 pays 5 76.3673 coins
	TxnID 330: 1 pays 8 18.9448 coins
	TxnID 331: 3 pays 7 77.7027 coins
	TxnID 332: 6 pays 7 20.381 coins
	TxnID 333: 4 pays 2 22.5136 coins
	TxnID 334: 0 pays 1 34.3787 coins
	TxnID 335: 7 pays 9 71.5638 coins
	TxnID 336: 5 pays 3 37.3986 coins
	TxnID 338: 1 pays 5 0.188785 coins
	TxnID 339: 1 pays 3 60.6866 coins
	TxnID 340: 9 pays 8 9.49646 coins
	TxnID 341: 9 pays 3 70.0858 coins
	TxnID 343: 2 pays 5 0.308015 coins
	TxnID 344: 8 pays 2 115.053 coins
	TxnID 345: 7 pays 4 45.61 coins
	TxnID 346: 8 pays 5 15.045 coins
	TxnID 347: 6 pays 8 6.14787 coins
	TxnID 349: 4 pays 3 17.2571 coins
	TxnID 351: 1 pays 7 34.715 coins
	TxnID 352: 9 pays 0 22.1479 coins
	TxnID 353: 0 pays 7 13.3114 coins
	TxnID 354: 6 pays 7 3.96225 coins
	TxnID 355: 6 pays 3 4.68324 coins
	TxnID 356: 7 pays 3 17.6172 coins
	TxnID 357: 2 pays 4 0.345425 coins
	TxnID 358: 2 pays 8 0.0874458 coins
	TxnID 359: 9 pays 8 16.5556 coins
	TxnID 366: 9 pays 5 78.7045 coins
	TxnID 367: 5 pays 3 7.72983 coins
	TxnID 368: 7 pays 5 76.1933 coins
	TxnID 369: 8 pays 6 70.8326 coins
	TxnID 370: 5 pays 8 54.4365 coins
	TxnID 371: 8 pays 0 4.05786 coins
	TxnID 373: 8 pays 7 55.1313 coins
	TxnID 380: -1 pays 8 50 coins
Block#11
--------------------------------------------------
Block ID:             11
Created by node:      6
Length in BlockChain: 12
Previous Block:       10
Created at:           38.8747
Received at:           39.3258
	TxnID 138: 2 pays 5 44.0895 coins
	TxnID 147: 2 pays 6 51.2431 coins
	TxnID 189: 4 pays 0 55.6017 coins
	TxnID 199: 4 pays 3 76.8669 coins
	TxnID 203: 2 pays 1 11.5335 coins
	TxnID 210: 2 pays 4 22.7034 coins
	TxnID 224: 2 pays 1 10.7116 coins
	TxnID 229: 4 pays 8 39.49 coins
	TxnID 234: 2 pays 1 20.6204 coins
	TxnID 235: 2 pays 1 26.0832 coins
	TxnID 249: 0 pays 1 100.92 coins
	TxnID 253: 2 pays 4 3.51644 coins
	TxnID 266: 6 pays 2 72.4001 coins
	TxnID 287: 6 pays 1 44.4523 coins
	TxnID 289: 5 pays 0 42.2883 coins
	TxnID 295: 5 pays 6 108.468 coins
	TxnID 300: 4 pays 8 5.36745 coins
	TxnID 309: 2 pays 9 59.1909 coins
	TxnID 337: 0 pays 1 55.0528 coins
	TxnID 362: 1 pays 4 30.7291 coins
	TxnID 365: 1 pays 9 65.307 coins
	TxnID 372: 7 pays 6 16.4256 coins
	TxnID 376: 9 pays 6 58.6744 coins
	TxnID 377: 8 pays 2 134.215 coins
	TxnID 378: 7 pays 1 9.98484 coins
	TxnID 379: 4 pays 9 83.4026 coins
	TxnID 381: 1 pays 8 34.6583 coins
	TxnID 383: 4 pays 0 13.3081 coins
	TxnID 385: 6 pays 4 4.82959 coins
	TxnID 386: 6 pays 4 48.2706 coins
	TxnID 388: 2 pays 8 0.0527745 coins
	TxnID 389: 9 pays 8 5.747 coins
	TxnID 393: 2 pays 4 0.217708 coins
	TxnID 394: 1 pays 4 10.3585 coins
	TxnID 395: 5 pays 8 0.799585 coins
	TxnID 396: 8 pays 6 92.4523 coins
	TxnID 398: 5 pays 0 4.41162 coins
	TxnID 404: -1 pays 6 50 coins
Block#12
--------------------------------------------------
Block ID:             12
Created by node:      0
Length in BlockChain: 13
Previous Block:       11
Created at:           44.5998
Received at:           45.2226
	TxnID 348: 7 pays 4 76.3101 coins
	TxnID 375: 5 pays 3 28.7756 coins
	TxnID 384: 7 pays 8 76.5198 coins
	TxnID 387: 6 pays 8 93.2301 coins
	TxnID 391: 8 pays 2 120.829 coins
	TxnID 397: 8 pays 4 97.7935 coins
	TxnID 399: 2 pays 8 91.687 coins
	TxnID 400: 5 pays 1 0.921977 coins
	TxnID 401: 8 pays 7 128.236 coins
	TxnID 402: 4 pays 9 168.949 coins
	TxnID 403: 2 pays 1 131.181 coins
	TxnID 405: 0 pays 9 25.5459 coins
	TxnID 406: 8 pays 5 0.528594 coins
	TxnID 407: 8 pays 1 1.06269 coins
	TxnID 408: 7 pays 3 1.25505 coins
	TxnID 411: 9 pays 5 41.2232 coins
	TxnID 412: 2 pays 6 63.1241 coins
	TxnID 413: 0 pays 3 8.07106 coins
	TxnID 414: 8 pays 1 10.562 coins
	TxnID 415: 1 pays 7 1.51118 coins
	TxnID 416: 1 pays 7 7.34333 coins
	TxnID 417: 3 pays 2 8.77127 coins
	TxnID 418: 8 pays 0 6.52153 coins
	TxnID 419: 3 pays 9 6.08571 coins
	TxnID 420: 5 pays 0 0.584933 coins
	TxnID 421: 2 pays 5 4.40542 coins
	TxnID 422: 6 pays 0 103.14 coins
	TxnID 423: 2 pays 7 74.8378 coins
	TxnID 424: 3 pays 2 2.95621 coins
	TxnID 426: 6 pays 9 0.548542 coins
	TxnID 427: 0 pays 5 23.2945 coins
	TxnID 428: 7 pays 0 0.365936 coins
	TxnID 429: 0 pays 6 14.0943 coins
	TxnID 430: 1 pays 5 14.3164 coins
	TxnID 431: 8 pays 7 2.04023 coins
	TxnID 432: 1 pays 9 9.6572 coins
	TxnID 433: 9 pays 6 68.85 coins
	TxnID 435: 8 pays 7 1.54411 coins
	TxnID 436: 1 pays 9 2.2141 coins
	TxnID 437: 8 pays 2 6.02284 coins
	TxnID 438: 0 pays 8 18.6941 coins
	TxnID 439: 9 pays 6 4.13904 coins
	TxnID 440: 7 pays 8 0.283421 coins
	TxnID 441: 7 pays 6 4.67148 coins
	TxnID 442: 0 pays 8 5.94121 coins
	TxnID 443: 5 pays 8 0.770529 coins
	TxnID 446: 5 pays 3 1.15145 coins
	TxnID 447: 5 pays 1 0.274129 coins
	TxnID 448: 7 pays 3 0.0769617 coins
	TxnID 449: 7 pays 2 4.48634 coins
	TxnID 450: 0 pays 2 7.91845 coins
	TxnID 451: 0 pays 9 31.538 coins
	TxnID 452: 1 pays 0 6.86787 coins
	TxnID 453: 9 pays 2 4.09178 coins
	TxnID 454: 6 pays 5 19.7695 coins
	TxnID 455: 9 pays 3 149.36 coins
	TxnID 456: 7 pays 4 4.67116 coins
	TxnID 457: 9 pays 3 15.2795 coins
	TxnID 464: -1 pays 0 50 coins
Block#13
--------------------------------------------------
Block ID:             13
Created by node:      4
Length in BlockChain: 14
Previous Block:       12
Created at:           45.7208
Received at:           46.2491
	TxnID 132: 5 pays 6 44.8663 coins
	TxnID 230: 4 pays 7 90.1146 coins
	TxnID 293: 7 pays 8 278.923 coins
	TxnID 360: 3 pays 4 105.579 coins
	TxnID 363: 3 pays 8 18.1852 coins
	TxnID 382: 3 pays 0 79.6412 coins
	TxnID 392: 7 pays 2 50.2999 coins
	TxnID 425: 3 pays 6 6.93718 coins
	TxnID 434: 3 pays 7 7.85107 coins
	TxnID 445: 4 pays 9 216.036 coins
	TxnID 458: 0 pays 7 29.1017 coins
	TxnID 459: 3 pays 8 6.68611 coins
	TxnID 460: 9 pays 0 6.86147 coins
	TxnID 462: 6 pays 5 154.97 coins
	TxnID 463: 8 pays 1 6.50791 coins
	TxnID 466: 7 pays 3 2.56878 coins
	TxnID 467: 1 pays 2 0.929703 coins
	TxnID 469: 7 pays 0 1.22892 coins
	TxnID 470: 7 pays 8 4.61566 coins
	TxnID 476: -1 pays 4 50 coins
Block#14
--------------------------------------------------
Block ID:             14
Created by node:      6
Length in BlockChain: 15
Previous Block:       13
Created at:           46.6615
Received at:           47.1125
	TxnID 471: 4 pays 7 7.34408 coins
	TxnID 473: 1 pays 0 89.4075 coins
	TxnID 474: 8 pays 5 8.27294 coins
	TxnID 475: 8 pays 1 9.99501 coins
	TxnID 477: 3 pays 2 112.729 coins
	TxnID 478: 6 pays 4 60.6052 coins
	TxnID 481: 5 pays 2 18.8292 coins
	TxnID 489: -1 pays 6 50 coins
Block#15
--------------------------------------------------
Block ID:             15
Created by node:      4
Length in BlockChain: 16
Previous Block:       14
Created at:           47.3783
Received at:           47.9057
	TxnID 307: 1 pays 2 205.843 coins
	TxnID 409: 4 pays 0 133.127 coins
	TxnID 444: 2 pays 0 151.346 coins
	TxnID 468: 2 pays 4 173.465 coins
	TxnID 472: 4 pays 7 30.475 coins
	TxnID 479: 2 pays 3 1.71009 coins
	TxnID 482: 6 pays 7 34.4729 coins
	TxnID 483: 3 pays 5 28.1994 coins
	TxnID 484: 4 pays 1 27.5426 coins
	TxnID 485: 8 pays 5 97.2986 coins
	TxnID 487: 8 pays 7 84.3224 coins
	TxnID 488: 7 pays 4 33.0655 coins
	TxnID 490: 0 pays 2 58.3675 coins
	TxnID 491: 4 pays 8 54.958 coins
	TxnID 492: 9 pays 0 8.31079 coins
	TxnID 493: 9 pays 6 8.11671 coins
	TxnID 497: -1 pays 4 50 coins
Block#16
--------------------------------------------------
Block ID:             16
Created by node:      6
Length in BlockChain: 17
Previous Block:       15
Created at:           50.1139
Received at:           50.5676
	TxnID 22: 0 pays 4 71.8027 coins
	TxnID 494: 1 pays 8 58.131 coins
	TxnID 495: 3 pays 8 15.5946 coins
	TxnID 496: 0 pays 6 3.31475 coins
	TxnID 498: 5 pays 1 35.6885 coins
	TxnID 499: 0 pays 5 3.47054 coins
	TxnID 500: 4 pays 3 7.28033 coins
	TxnID 501: 2 pays 0 116.696 coins
	TxnID 502: 3 pays 1 11.718 coins
	TxnID 503: 9 pays 8 18.9577 coins
	TxnID 504: 6 pays 8 82.6907 coins
	TxnID 505: 4 pays 3 49.5718 coins
	TxnID 506: 3 pays 8 3.3321 coins
	TxnID 508: 3 pays 4 1.88181 coins
	TxnID 511: 2 pays 0 58.4648 coins
	TxnID 512: 8 pays 4 233.678 coins
	TxnID 515: 2 pays 4 100.227 coins
	TxnID 516: 3 pays 9 1.04772 coins
	TxnID 519: 4 pays 1 20.1662 coins
	TxnID 520: 4 pays 6 41.0196 coins
	TxnID 522: 0 pays 9 112.718 coins
	TxnID 528: 6 pays 7 47.8813 coins
	TxnID 529: -1 pays 6 50 coins
Block#17
--------------------------------------------------
Block ID:             17
Created by node:      4
Length in BlockChain: 18
Previous Block:       16
Created at:           54.0561
Received at:           54.5848
	TxnID 342: 4 pays 6 101.795 coins
	TxnID 390: 7 pays 0 100.41 coins
	TxnID 465: 6 pays 3 126.659 coins
	TxnID 480: 3 pays 7 89.4549 coins
	TxnID 486: 3 pays 9 65.4652 coins
	TxnID 507: 9 pays 6 5.72198 coins
	TxnID 514: 9 pays 4 15.9746 coins
	TxnID 517: 6 pays 1 32.0193 coins
	TxnID 527: 3 pays 6 1.63827 coins
	TxnID 530: 1 pays 4 28.7551 coins
	TxnID 532: 2 pays 6 54.8999 coins
	TxnID 536: 3 pays 6 6.51865 coins
	TxnID 537: 5 pays 7 7.1887 coins
	TxnID 539: 2 pays 1 24.1877 coins
	TxnID 540: 2 pays 1 7.8972 coins
	TxnID 541: 7 pays 6 96.3201 coins
	TxnID 543: 7 pays 3 8.53765 coins
	TxnID 545: 1 pays 5 26.7705 coins
	TxnID 546: 8 pays 7 9.0884 coins
	TxnID 547: 5 pays 9 2.95829 coins
	TxnID 548: 1 pays 8 195.163 coins
	TxnID 549: 6 pays 1 91.1293 coins
	TxnID 550: 0 pays 9 2.09176 coins
	TxnID 551: 9 pays 2 8.92245 coins
	TxnID 552: 8 pays 4 167.696 coins
	TxnID 553: 2 pays 4 2.27719 coins
	TxnID 554: 9 pays 2 91.3232 coins
	TxnID 555: 9 pays 3 4.44565 coins
	TxnID 558: 5 pays 8 1.47452 coins
	TxnID 559: 8 pays 4 105.499 coins
	TxnID 560: 5 pays 0 9.38617 coins
	TxnID 561: 5 pays 1 6.21993 coins
	TxnID 562: 2 pays 8 5.83676 coins
	TxnID 567: 6 pays 5 58.9763 coins
	TxnID 568: 0 pays 9 2.31307 coins
	TxnID 569: -1 pays 4 50 coins
Block#18
--------------------------------------------------
Block ID:             18
Created by node:      3
Length in BlockChain: 19
Previous Block:       17
Created at:           55.8852
Received at:           56.9194
	TxnID 48: 0 pays 8 52.4413 coins
	TxnID 277: 5 pays 1 68.6548 coins
	TxnID 350: 5 pays 2 53.3021 coins
	TxnID 364: 3 pays 9 167.273 coins
	TxnID 374: 5 pays 4 43.1301 coins
	TxnID 410: 4 pays 8 218.736 coins
	TxnID 509: 2 pays 3 87.6341 coins
	TxnID 510: 5 pays 6 23.41 coins
	TxnID 513: 2 pays 1 49.8582 coins
	TxnID 518: 2 pays 0 41.4966 coins
	TxnID 525: 2 pays 5 45.4262 coins
	TxnID 531: 7 pays 4 122.319 coins
	TxnID 570: 9 pays 1 54.1896 coins
	TxnID 571: 4 pays 1 18.927 coins
	TxnID 572: 0 pays 3 98.6947 coins
	TxnID 573: 1 pays 9 41.4917 coins
	TxnID 574: 1 pays 5 29.0544 coins
	TxnID 575: 8 pays 9 258.686 coins
	TxnID 576: 8 pays 9 299.698 coins
	TxnID 577: 3 pays 1 5.50416 coins
	TxnID 578: 3 pays 8 32.6913 coins
	TxnID 580: 6 pays 5 5.82855 coins
	TxnID 581: 6 pays 8 9.87449 coins
	TxnID 582: 3 pays 6 40.3508 coins
	TxnID 590: -1 pays 3 50 coins
Block#19
--------------------------------------------------
Block ID:             19
Created by node:      2
Length in BlockChain: 20
Previous Block:       18
Created at:           58.2239
Received at:           59.3934
	TxnID 542: 3 pays 7 36.5284 coins
	TxnID 563: 3 pays 1 34.9632 coins
	TxnID 564: 7 pays 6 76.6391 coins
	TxnID 565: 6 pays 7 84.6977 coins
	TxnID 566: 7 pays 8 107.232 coins
	TxnID 579: 1 pays 7 70.1919 coins
	TxnID 585: 9 pays 1 35.632 coins
	TxnID 587: 9 pays 0 42.292 coins
	TxnID 588: 1 pays 9 57.9955 coins
	TxnID 591: 8 pays 9 249.247 coins
	TxnID 594: 7 pays 1 11.2141 coins
	TxnID 595: 1 pays 9 105.549 coins
	TxnID 596: 1 pays 7 8.51814 coins
	TxnID 597: 2 pays 8 8.01996 coins
	TxnID 598: 9 pays 2 214.094 coins
	TxnID 599: 2 pays 8 8.1823 coins
	TxnID 601: 8 pays 1 8.61779 coins
	TxnID 602: 0 pays 3 5.99258 coins
	TxnID 603: 7 pays 3 1.52105 coins
	TxnID 606: 1 pays 5 4.08041 coins
	TxnID 615: -1 pays 2 50 coins
Block#20
--------------------------------------------------
Block ID:             20
Created by node:      4
Length in BlockChain: 21
Previous Block:       19
Created at:           63.5275
Received at:           64.0551
	TxnID 544: 2 pays 3 33.3423 coins
	TxnID 600: 5 pays 7 133.902 coins
	TxnID 604: 6 pays 8 26.0483 coins
	TxnID 605: 4 pays 6 7.16439 coins
	TxnID 608: 3 pays 0 63.7365 coins
	TxnID 610: 7 pays 9 46.0951 coins
	TxnID 613: 1 pays 5 33.878 coins
	TxnID 617: 0 pays 1 9.28077 coins
	TxnID 618: 7 pays 1 19.5847 coins
	TxnID 619: 7 pays 4 16.7626 coins
	TxnID 620: 4 pays 2 5.62781 coins
	TxnID 622: 7 pays 9 87.8165 coins
	TxnID 624: 6 pays 1 49.1238 coins
	TxnID 626: 3 pays 0 0.125285 coins
	TxnID 627: 4 pays 7 0.369708 coins
	TxnID 628: 3 pays 2 2.30274 coins
	TxnID 629: 6 pays 8 26.2907 coins
	TxnID 630: 7 pays 8 104.816 coins
	TxnID 632: 8 pays 6 42.4154 coins
	TxnID 633: 9 pays 6 80.3085 coins
	TxnID 634: 5 pays 0 37.755 coins
	TxnID 635: 7 pays 9 9.54151 coins
	TxnID 636: 1 pays 9 23.5416 coins
	TxnID 637: 4 pays 1 3.51142 coins
	TxnID 638: 9 pays 1 161.864 coins
	TxnID 639: 8 pays 7 68.0772 coins
	TxnID 640: 9 pays 2 305.203 coins
	TxnID 641: 8 pays 5 116.089 coins
	TxnID 642: 2 pays 4 77.4946 coins
	TxnID 643: 4 pays 6 7.23543 coins
	TxnID 644: 4 pays 0 6.80789 coins
	TxnID 645: 5 pays 7 38.1983 coins
	TxnID 649: 0 pays 9 25.2479 coins
	TxnID 650: 1 pays 8 66.0725 coins
	TxnID 651: 7 pays 9 37.2969 coins
	TxnID 652: 7 pays 1 65.4527 coins
	TxnID 653: 6 pays 3 5.41432 coins
	TxnID 654: 8 pays 5 205.42 coins
	TxnID 655: 1 pays 2 50.0712 coins
	TxnID 657: 1 pays 5 17.1426 coins
	TxnID 659: 4 pays 8 6.65781 coins
	TxnID 660: 6 pays 2 35.9592 coins
	TxnID 665: -1 pays 4 50 coins
Block#21
--------------------------------------------------
Block ID:             21
Created by node:      6
Length in BlockChain: 22
Previous Block:       20
Created at:           68.2311
Received at:           68.6825
	TxnID 611: 1 pays 9 149.097 coins
	TxnID 612: 4 pays 3 2.44655 coins
	TxnID 614: 4 pays 7 4.18036 coins
	TxnID 616: 1 pays 3 119.884 coins
	TxnID 623: 5 pays 8 166.849 coins
	TxnID 661: 3 pays 1 8.0654 coins
	TxnID 663: 8 pays 6 131.186 coins
	TxnID 666: 4 pays 0 52.3426 coins
	TxnID 668: 2 pays 9 52.5905 coins
	TxnID 669: 0 pays 6 6.58616 coins
	TxnID 671: 1 pays 2 48.8047 coins
	TxnID 672: 3 pays 1 8.77391 coins
	TxnID 673: 8 pays 6 92.5742 coins
	TxnID 674: 3 pays 0 2.16415 coins
	TxnID 676: 3 pays 7 22.7703 coins
	TxnID 678: 3 pays 1 12.9586 coins
	TxnID 680: 4 pays 6 29.6033 coins
	TxnID 681: 9 pays 4 2.35304 coins
	TxnID 682: 8 pays 2 62.3808 coins
	TxnID 683: 0 pays 1 10.4067 coins
	TxnID 684: 4 pays 3 77.7374 coins
	TxnID 685: 4 pays 9 9.70464 coins
	TxnID 686: 4 pays 6 38.4701 coins
	TxnID 687: 3 pays 8 24.1165 coins
	TxnID 688: 4 pays 9 37.6982 coins
	TxnID 689: 8 pays 2 48.0096 coins
	TxnID 690: 6 pays 9 37.3137 coins
	TxnID 691: 5 pays 4 100.432 coins
	TxnID 693: 9 pays 2 58.9179 coins
	TxnID 694: 0 pays 1 36.5366 coins
	TxnID 695: 9 pays 6 40.6292 coins
	TxnID 696: 3 pays 6 18.2797 coins
	TxnID 699: 4 pays 8 114.564 coins
	TxnID 700: 1 pays 8 55.8253 coins
	TxnID 701: 9 pays 2 37.7204 coins
	TxnID 702: 6 pays 9 50.0163 coins
	TxnID 703: 7 pays 3 3.87122 coins
	TxnID 705: 2 pays 0 156.45 coins
	TxnID 706: 6 pays 4 87.0819 coins
	TxnID 707: 6 pays 0 72.1359 coins
	TxnID 708: 6 pays 8 63.8646 coins
	TxnID 709: 3 pays 8 35.5446 coins
	TxnID 710: 9 pays 8 58.4593 coins
	TxnID 713: -1 pays 6 50 coins
Block#22
--------------------------------------------------
Block ID:             22
Created by node:      9
Length in BlockChain: 23
Previous Block:       21
Created at:           68.5246
Received at:           68.7548
	TxnID 526: 2 pays 0 38.551 coins
	TxnID 533: 6 pays 7 94.2495 coins
	TxnID 583: 5 pays 1 177.139 coins
	TxnID 584: 3 pays 2 40.5315 coins
	TxnID 589: 2 pays 9 71.142 coins
	TxnID 592: 0 pays 4 68.8936 coins
	TxnID 607: 5 pays 1 61.2056 coins
	TxnID 609: 6 pays 8 48.7677 coins
	TxnID 697: 7 pays 1 36.1059 coins
	TxnID 704: 7 pays 3 40.6303 coins
	TxnID 712: 5 pays 4 133.815 coins
	TxnID 716: -1 pays 9 50 coins
Block#23
--------------------------------------------------
Block ID:             23
Created by node:      0
Length in BlockChain: 24
Previous Block:       22
Created at:           70.5795
Received at:           71.2015
	TxnID 524: 5 pays 7 149.434 coins
	TxnID 722: 9 pays 1 23.0971 coins
	TxnID 724: 1 pays 2 60.9832 coins
	TxnID 727: 2 pays 8 13.6813 coins
	TxnID 728: 1 pays 0 102.075 coins
	TxnID 730: 6 pays 3 1.35162 coins
	TxnID 732: 6 pays 9 1.3245 coins
	TxnID 737: -1 pays 0 50 coins
Block#24
--------------------------------------------------
Block ID:             24
Created by node:      6
Length in BlockChain: 25
Previous Block:       23
Created at:           73.1301
Received at:           73.5798
	TxnID 733: 5 pays 0 302.004 coins
	TxnID 738: 1 pays 0 211.101 coins
	TxnID 739: 4 pays 9 142.242 coins
	TxnID 740: 1 pays 2 36.2808 coins
	TxnID 741: 0 pays 8 22.2365 coins
	TxnID 742: 7 pays 2 12.5753 coins
	TxnID 743: 3 pays 8 17.6367 coins
	TxnID 746: 9 pays 4 129.775 coins
	TxnID 747: 6 pays 7 2.81792 coins
	TxnID 748: 1 pays 0 24.1482 coins
	TxnID 752: 6 pays 7 4.52903 coins
	TxnID 754: 3 pays 2 2.29029 coins
	TxnID 755: 9 pays 8 39.8148 coins
	TxnID 756: 9 pays 5 18.0158 coins
	TxnID 758: 6 pays 2 2.83991 coins
	TxnID 759: 6 pays 1 3.75727 coins
	TxnID 761: -1 pays 6 50 coins
Block#25
--------------------------------------------------
Block ID:             25
Created by node:      5
Length in BlockChain: 26
Previous Block:       24
Created at:           83.0952
Received at:           83.3048
	TxnID 714: 6 pays 3 34.8489 coins
	TxnID 734: 8 pays 1 79.5123 coins
	TxnID 735: 8 pays 0 12.4614 coins
	TxnID 736: 1 pays 6 196.869 coins
	TxnID 760: 8 pays 0 2.01703 coins
	TxnID 765: 8 pays 2 6.92181 coins
	TxnID 766: 9 pays 6 113.525 coins
	TxnID 767: 3 pays 8 8.83641 coins
	TxnID 769: 6 pays 4 225.036 coins
	TxnID 770: 7 pays 6 7.94598 coins
	TxnID 771: 5 pays 9 15.1366 coins
	TxnID 774: 9 pays 8 158.652 coins
	TxnID 775: 5 pays 9 3.23037 coins
	TxnID 776: 4 pays 1 58.9745 coins
	TxnID 788: 2 pays 0 3.2275 coins
	TxnID 791: 4 pays 3 10.3818 coins
	TxnID 792: 7 pays 0 7.84917 coins
	TxnID 793: 2 pays 4 1.41558 coins
	TxnID 795: 3 pays 0 4.94082 coins
	TxnID 798: 6 pays 2 65.4665 coins
	TxnID 799: 4 pays 9 48.8183 coins
	TxnID 800: 3 pays 7 5.00676 coins
	TxnID 803: 0 pays 8 320.704 coins
	TxnID 804: 2 pays 8 2.72207 coins
	TxnID 809: 8 pays 6 93.5268 coins
	TxnID 813: 6 pays 8 213.644 coins
	TxnID 814: 2 pays 4 9.25054 coins
	TxnID 817: 3 pays 5 0.276435 coins
	TxnID 818: 6 pays 9 25.7419 coins
	TxnID 820: 1 pays 0 2.08614 coins
	TxnID 821: 2 pays 5 2.95942 coins
	TxnID 822: 6 pays 4 206.334 coins
	TxnID 823: 1 pays 2 17.1607 coins
	TxnID 824: 2 pays 9 7.10167 coins
	TxnID 825: 2 pays 0 3.89771 coins
	TxnID 827: 8 pays 4 1.03411 coins
	TxnID 828: 1 pays 6 39.426 coins
	TxnID 830: 7 pays 6 10.9233 coins
	TxnID 831: 4 pays 9 56.9735 coins
	TxnID 832: 4 pays 3 2.95071 coins
	TxnID 835: 7 pays 4 10.4301 coins
	TxnID 837: 7 pays 4 0.514436 coins
	TxnID 838: 9 pays 7 59.315 coins
	TxnID 839: 2 pays 4 1.06178 coins
	TxnID 841: 4 pays 5 113.137 coins
	TxnID 842: 6 pays 8 235.049 coins
	TxnID 845: 3 pays 5 4.4541 coins
	TxnID 846: 1 pays 9 14.7258 coins
	TxnID 849: 6 pays 8 177.93 coins
	TxnID 851: 0 pays 4 187.399 coins
	TxnID 853: 7 pays 1 5.65718 coins
	TxnID 855: 8 pays 7 32.0328 coins
	TxnID 862: 8 pays 0 90.9094 coins
	TxnID 864: 8 pays 1 17.695 coins
	TxnID 867: -1 pays 5 50 coins
Block#26
--------------------------------------------------
Block ID:             26
Created by node:      4
Length in BlockChain: 26
Previous Block:       24
Created at:           83.2965
Received at:           83.8234
	TxnID 714: 6 pays 3 34.8489 coins
	TxnID 726: 3 pays 7 61.0434 coins
	TxnID 729: 3 pays 8 60.6912 coins
	TxnID 731: 7 pays 8 54.2431 coins
	TxnID 734: 8 pays 1 79.5123 coins
	TxnID 735: 8 pays 0 12.4614 coins
	TxnID 760: 8 pays 0 2.01703 coins
	TxnID 762: 8 pays 1 6.01671 coins
	TxnID 764: 1 pays 5 149.213 coins
	TxnID 765: 8 pays 2 6.92181 coins
	TxnID 766: 9 pays 6 113.525 coins
	TxnID 767: 3 pays 8 8.83641 coins
	TxnID 769: 6 pays 4 225.036 coins
	TxnID 770: 7 pays 6 7.94598 coins
	TxnID 771: 5 pays 9 15.1366 coins
	TxnID 772: 2 pays 5 7.90683 coins
	TxnID 773: 2 pays 8 7.20104 coins
	TxnID 774: 9 pays 8 158.652 coins
	TxnID 775: 5 pays 9 3.23037 coins
	TxnID 777: 3 pays 1 3.59437 coins
	TxnID 778: 5 pays 6 58.9124 coins
	TxnID 780: 3 pays 4 7.43069 coins
	TxnID 782: 3 pays 8 3.70052 coins
	TxnID 784: 9 pays 8 49.4148 coins
	TxnID 791: 4 pays 3 10.3818 coins
	TxnID 793: 2 pays 4 1.41558 coins
	TxnID 795: 3 pays 0 4.94082 coins
	TxnID 796: 5 pays 6 36.8376 coins
	TxnID 798: 6 pays 2 65.4665 coins
	TxnID 804: 2 pays 8 2.72207 coins
	TxnID 809: 8 pays 6 93.5268 coins
	TxnID 811: 4 pays 8 129.615 coins
	TxnID 813: 6 pays 8 213.644 coins
	TxnID 814: 2 pays 4 9.25054 coins
	TxnID 816: 5 pays 7 50.7928 coins
	TxnID 817: 3 pays 5 0.276435 coins
	TxnID 818: 6 pays 9 25.7419 coins
	TxnID 820: 1 pays 0 2.08614 coins
	TxnID 821: 2 pays 5 2.95942 coins
	TxnID 822: 6 pays 4 206.334 coins
	TxnID 823: 1 pays 2 17.1607 coins
	TxnID 824: 2 pays 9 7.10167 coins
	TxnID 825: 2 pays 0 3.89771 coins
	TxnID 826: 8 pays 7 40.2198 coins
	TxnID 827: 8 pays 4 1.03411 coins
	TxnID 830: 7 pays 6 10.9233 coins
	TxnID 831: 4 pays 9 56.9735 coins
	TxnID 832: 4 pays 3 2.95071 coins
	TxnID 833: 8 pays 4 25.9294 coins
	TxnID 835: 7 pays 4 10.4301 coins
	TxnID 836: 7 pays 1 19.5782 coins
	TxnID 837: 7 pays 4 0.514436 coins
	TxnID 838: 9 pays 7 59.315 coins
	TxnID 839: 2 pays 4 1.06178 coins
	TxnID 840: 8 pays 4 40.6878 coins
	TxnID 841: 4 pays 5 113.137 coins
	TxnID 842: 6 pays 8 235.049 coins
	TxnID 844: 0 pays 3 193.208 coins
	TxnID 845: 3 pays 5 4.4541 coins
	TxnID 846: 1 pays 9 14.7258 coins
	TxnID 847: 4 pays 7 63.4979 coins
	TxnID 849: 6 pays 8 177.93 coins
	TxnID 852: 6 pays 8 311.769 coins
	TxnID 853: 7 pays 1 5.65718 coins
	TxnID 854: 4 pays 1 61.6009 coins
	TxnID 855: 8 pays 7 32.0328 coins
	TxnID 856: 9 pays 0 104.176 coins
	TxnID 857: 2 pays 9 2.2923 coins
	TxnID 861: 1 pays 3 43.3895 coins
	TxnID 862: 8 pays 0 90.9094 coins
	TxnID 863: 0 pays 1 272.259 coins
	TxnID 864: 8 pays 1 17.695 coins
	TxnID 871: -1 pays 4 50 coins
Block#27
--------------------------------------------------
Block ID:             27
Created by node:      5
Length in BlockChain: 27
Previous Block:       26
Created at:           85.2155
Received at:           85.4233
	TxnID 779: 9 pays 3 153.678 coins
	TxnID 783: 0 pays 6 484.21 coins
	TxnID 785: 3 pays 4 5.45687 coins
	TxnID 786: 2 pays 3 9.00099 coins
	TxnID 787: 7 pays 5 14.6939 coins
	TxnID 788: 2 pays 0 3.2275 coins
	TxnID 790: 2 pays 9 6.5594 coins
	TxnID 792: 7 pays 0 7.84917 coins
	TxnID 797: 0 pays 3 379.219 coins
	TxnID 800: 3 pays 7 5.00676 coins
	TxnID 802: 5 pays 2 30.1951 coins
	TxnID 808: 3 pays 8 4.28702 coins
	TxnID 812: 3 pays 9 6.5103 coins
	TxnID 848: 3 pays 2 2.42439 coins
	TxnID 860: 2 pays 3 4.74346 coins
	TxnID 866: 9 pays 4 194.539 coins
	TxnID 867: -1 pays 5 50 coins
	TxnID 869: 1 pays 3 1.70418 coins
	TxnID 872: 9 pays 1 37.5836 coins
	TxnID 873: 3 pays 4 5.18289 coins
	TxnID 874: 6 pays 2 227.299 coins
	TxnID 875: 1 pays 7 15.1992 coins
	TxnID 877: 8 pays 5 665.22 coins
	TxnID 878: 2 pays 8 0.0374152 coins
	TxnID 881: 0 pays 6 2.64022 coins
	TxnID 882: 6 pays 2 39.2575 coins
	TxnID 883: 8 pays 5 34.2346 coins
	TxnID 884: 5 pays 3 118.483 coins
	TxnID 892: -1 pays 5 50 coins
Block#28
--------------------------------------------------
Block ID:             28
Created by node:      6
Length in BlockChain: 28
Previous Block:       27
Created at:           92.4436
Received at:           92.8979
	TxnID 744: 4 pays 8 42.8676 coins
	TxnID 768: 4 pays 6 56.9115 coins
	TxnID 776: 4 pays 1 58.9745 coins
	TxnID 801: 4 pays 5 140.631 coins
	TxnID 810: 9 pays 8 219.845 coins
	TxnID 819: 9 pays 7 223.851 coins
	TxnID 828: 1 pays 6 39.426 coins
	TxnID 843: 0 pays 7 159.548 coins
	TxnID 865: 8 pays 4 85.4318 coins
	TxnID 870: 8 pays 0 61.7147 coins
	TxnID 879: 1 pays 8 13.9326 coins
	TxnID 885: 0 pays 4 2.84368 coins
	TxnID 887: 4 pays 6 35.9008 coins
	TxnID 888: 0 pays 9 0.0667439 coins
	TxnID 889: 3 pays 4 1.19518 coins
	TxnID 891: 9 pays 0 9.03351 coins
	TxnID 894: 3 pays 9 0.383401 coins
	TxnID 895: 5 pays 6 34.6201 coins
	TxnID 896: 0 pays 3 2.41316 coins
	TxnID 897: 6 pays 4 67.8367 coins
	TxnID 898: 9 pays 5 0.0525484 coins
	TxnID 900: 9 pays 8 10.1185 coins
	TxnID 901: 0 pays 6 1.60822 coins
	TxnID 902: 5 pays 2 8.83392 coins
	TxnID 903: 5 pays 0 15.6711 coins
	TxnID 904: 6 pays 2 11.5422 coins
	TxnID 905: 3 pays 8 0.0944273 coins
	TxnID 906: 5 pays 4 27.7595 coins
	TxnID 908: 6 pays 7 618.36 coins
	TxnID 909: 6 pays 8 295.442 coins
	TxnID 910: 7 pays 8 231.592 coins
	TxnID 911: 7 pays 5 132.703 coins
	TxnID 913: 1 pays 3 6.05032 coins
	TxnID 914: 5 pays 7 60.9586 coins
	TxnID 915: 7 pays 1 107.044 coins
	TxnID 916: 5 pays 1 47.5084 coins
	TxnID 922: 0 pays 9 8.02809 coins
	TxnID 923: 1 pays 5 12.4135 coins
	TxnID 925: 1 pays 5 5.09268 coins
	TxnID 927: 5 pays 6 57.5884 coins
	TxnID 928: 8 pays 6 9.74457 coins
	TxnID 929: 6 pays 3 277.111 coins
	TxnID 930: 7 pays 0 109.194 coins
	TxnID 932: 1 pays 7 9.60863 coins
	TxnID 933: 1 pays 0 11.8163 coins
	TxnID 935: 3 pays 8 134.561 coins
	TxnID 936: 8 pays 9 8.95578 coins
	TxnID 937: 4 pays 1 1.0094 coins
	TxnID 939: 8 pays 0 1.81995 coins
	TxnID 941: 7 pays 1 234.461 coins
	TxnID 944: 4 pays 7 36.6461 coins
	TxnID 946: 6 pays 3 249.417 coins
	TxnID 947: 1 pays 5 7.50816 coins
	TxnID 948: 8 pays 0 17.0574 coins
	TxnID 949: 1 pays 0 12.9244 coins
	TxnID 950: 5 pays 3 24.8116 coins
	TxnID 951: 8 pays 9 7.30357 coins
	TxnID 952: 5 pays 0 55.4739 coins
	TxnID 954: 2 pays 0 264.784 coins
	TxnID 956: 1 pays 2 8.36544 coins
	TxnID 957: 8 pays 6 1.0935 coins
	TxnID 958: 1 pays 3 9.31732 coins
	TxnID 965: 8 pays 7 14.3163 coins
	TxnID 968: 1 pays 0 5.38469 coins
	TxnID 969: 8 pays 9 3.99116 coins
	TxnID 971: 9 pays 4 18.5032 coins
	TxnID 975: -1 pays 6 50 coins
Block#29
--------------------------------------------------
Block ID:             29
Created by node:      2
Length in BlockChain: 29
Previous Block:       28
Created at:           94.6139
Received at:           95.7806
	TxnID 725: 4 pays 6 253.755 coins
	TxnID 757: 7 pays 9 301.975 coins
	TxnID 781: 5 pays 2 48.1711 coins
	TxnID 789: 5 pays 4 41.3878 coins
	TxnID 794: 4 pays 5 133.695 coins
	TxnID 799: 4 pays 9 48.8183 coins
	TxnID 805: 5 pays 1 66.1602 coins
	TxnID 807: 4 pays 0 47.6318 coins
	TxnID 850: 9 pays 5 163.79 coins
	TxnID 859: 9 pays 5 117.519 coins
	TxnID 876: 8 pays 6 570.129 coins
	TxnID 886: 2 pays 6 18.6235 coins
	TxnID 893: 2 pays 1 18.9803 coins
	TxnID 907: 7 pays 3 95.7984 coins
	TxnID 917: 2 pays 0 40.4993 coins
	TxnID 918: 3 pays 1 37.02 coins
	TxnID 919: 3 pays 7 20.5761 coins
	TxnID 921: 3 pays 5 322.088 coins
	TxnID 931: 6 pays 4 270.901 coins
	TxnID 938: 6 pays 4 296.073 coins
	TxnID 940: 6 pays 3 155.956 coins
	TxnID 953: 2 pays 9 45.076 coins
	TxnID 959: 7 pays 1 84.8649 coins
	TxnID 960: 5 pays 2 32.4191 coins
	TxnID 963: 5 pays 1 61.295 coins
	TxnID 970: 1 pays 5 8.90172 coins
	TxnID 972: 5 pays 4 16.1535 coins
	TxnID 973: 5 pays 8 19.8368 coins
	TxnID 974: 7 pays 1 25.3572 coins
	TxnID 976: 5 pays 4 9.85574 coins
	TxnID 977: 8 pays 1 6.57674 coins
	TxnID 978: 6 pays 8 49.4538 coins
	TxnID 980: 0 pays 8 9.64424 coins
	TxnID 983: 3 pays 9 200.696 coins
	TxnID 985: 4 pays 7 48.3001 coins
	TxnID 986: 4 pays 2 182.914 coins
	TxnID 987: 6 pays 3 72.3841 coins
	TxnID 988: 4 pays 7 199.53 coins
	TxnID 989: 1 pays 5 54.9497 coins
	TxnID 990: 7 pays 4 53.7437 coins
	TxnID 991: 1 pays 3 55.6556 coins
	TxnID 994: 2 pays 3 4.62796 coins
	TxnID 995: 2 pays 6 4.94484 coins
	TxnID 996: 2 pays 9 55.8516 coins
	TxnID 1001: -1 pays 2 50 coins
